package com.example.builder;


public class Main {
 public static void main(String[] args) {
     // Create a basic computer with only required parameters
     Computer basicComputer = new Computer.Builder("Intel i5", "8GB").build();
     System.out.println(basicComputer);

     // Create a high-end computer with all optional parameters
     Computer highEndComputer = new Computer.Builder("Intel i9", "32GB")
             .setStorage("1TB SSD")
             .setGraphicsCard("NVIDIA RTX 3080")
             .setOperatingSystem("Windows 11")
             .setBluetoothEnabled(true)
             .setWiFiEnabled(true)
             .build();
     System.out.println(highEndComputer);

     // Create a mid-range computer with some optional parameters
     Computer midRangeComputer = new Computer.Builder("AMD Ryzen 5", "16GB")
             .setStorage("512GB SSD")
             .setOperatingSystem("Linux")
             .setWiFiEnabled(true)
             .build();
     System.out.println(midRangeComputer);
 }
}
