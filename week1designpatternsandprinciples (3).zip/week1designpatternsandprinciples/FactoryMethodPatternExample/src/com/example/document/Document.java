// File: src/main/java/com/example/document/Document.java
package com.example.document;

public interface Document {
    void open();
    void close();
    void save();
}
