package com.example.strategy;

public interface PaymentStrategy {
    void pay(double amount);
}

