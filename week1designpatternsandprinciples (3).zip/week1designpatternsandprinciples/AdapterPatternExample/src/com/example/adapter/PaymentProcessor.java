package com.example.adapter;

public interface PaymentProcessor {
 void processPayment(double amount);
}
