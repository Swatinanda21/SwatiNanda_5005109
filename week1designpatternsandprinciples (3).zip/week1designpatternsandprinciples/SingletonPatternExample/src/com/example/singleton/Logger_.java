package com.example.singleton;

public class Logger_ {
    // Private static instance of the Logger class
    private static Logger_ instance;

    // Private constructor to prevent instantiation
    private Logger_() {
    }

    // Public static method to get the instance of the Logger class
    public static Logger_ getInstance() {
        if (instance == null) {
            instance = new Logger_();
        }
        return instance;
    }

    // Method to log messages
    public void log(String message) {
        System.out.println("Log message: " + message);
    }
}
