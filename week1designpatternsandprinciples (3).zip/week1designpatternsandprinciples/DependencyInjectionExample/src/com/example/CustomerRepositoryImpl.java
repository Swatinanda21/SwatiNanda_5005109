// File: src/main/java/com/example/CustomerRepositoryImpl.java
package com.example;

public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(int id) {
        // Dummy implementation for demonstration purposes
        return new Customer(id, "John Doe");
    }
}
