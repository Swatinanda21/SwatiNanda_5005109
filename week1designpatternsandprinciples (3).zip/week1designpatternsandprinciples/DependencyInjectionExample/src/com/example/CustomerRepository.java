// File: src/main/java/com/example/CustomerRepository.java
package com.example;

public interface CustomerRepository {
    Customer findCustomerById(int id);
}
