package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;

import org.hibernate.query.Page;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.awt.print.Pageable;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    
    // Derived query method to find employees by name
    List<Employee> findByName(String name);
    
    // Derived query method to find employees by department id
    List<Employee> findByDepartmentId(Long departmentId);
   // Custom query to find employees by email using @Query
    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    Employee findByEmail(@Param("email") String email);
   // Paginated list of employees
    Page findAll(Pageable pageable);
    // Sort employees by name
    List<Employee> findAll(Sort sort);
}
