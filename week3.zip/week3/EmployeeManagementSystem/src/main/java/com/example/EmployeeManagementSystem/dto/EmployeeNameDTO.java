package com.example.EmployeeManagementSystem.dto;

public class EmployeeNameDTO {
    private String name;

    public EmployeeNameDTO(String name) {
        this.name = name;
    }

    // Getters and setters...
}
