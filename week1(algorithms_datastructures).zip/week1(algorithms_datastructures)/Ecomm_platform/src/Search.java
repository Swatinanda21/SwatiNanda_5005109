public class Search {
    public Product linearSearch(Product[] products, String productName) {
        for (Product product : products) {
            if (product.getProductName().equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null; // Product not found
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
