

	import java.util.HashMap;

	public class Inventory_Management {
	    private HashMap<String, Product> inventory;

	    public Inventory_Management() {
	        this.inventory = new HashMap<>();
	    }

	    public void addProduct(Product product) {
	        inventory.put(product.getProductId(), product);
	    }

	    public void updateProduct(Product product) {
	        if (inventory.containsKey(product.getProductId())) {
	            inventory.put(product.getProductId(), product);
	        } else {
	            System.out.println("Product not found in the inventory.");
	        }
	    }

	    public void deleteProduct(String productId) {
	        if (inventory.containsKey(productId)) {
	            inventory.remove(productId);
	        } else {
	            System.out.println("Product not found in the inventory.");
	        }
	    }

	    public Product getProduct(String productId) {
	        return inventory.get(productId);
	    }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
